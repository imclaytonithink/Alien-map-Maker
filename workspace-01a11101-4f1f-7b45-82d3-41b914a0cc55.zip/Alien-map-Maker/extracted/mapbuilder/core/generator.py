"""Themed map generator (ALIENS RPG).

Classifies imported assets by filename into semantic categories, then lays out
connected rooms + corridors and places fixtures on the correct surfaces.
Pure logic (no Qt) so it can be unit-tested headlessly; the UI passes the
taxonomy in and gets back a list of piece dicts ready for Project.
"""
from __future__ import annotations

import math
import random
from typing import Optional

CATEGORIES = ["floor", "wall", "corridor", "door",
              "wall_fixture", "floor_fixture", "hazard"]

KEYWORDS = {
    "floor": ["floor", "deck", "deckplate", "tile", "grating", "carpet",
              "ground", "plate", "mat"],
    "wall": ["wall", "bulkhead", "hull", "partition", "barrier"],
    "corridor": ["corridor", "hall", "hallway", "passage", "tunnel"],
    "door": ["door", "hatch", "airlock", "portal", "gate"],
    "wall_fixture": ["terminal", "computer", "console", "screen", "monitor",
                     "display", "panel", "switch", "controls", "keypad",
                     "intercom", "reactor", "valve", "gauge"],
    "floor_fixture": ["crate", "locker", "bed", "cryo", "cryopod", "table",
                      "chair", "barrel", "box", "pallet", "corpse", "body",
                      "canister", "shelf", "rack", "stool", "cabinet", "tube"],
    "hazard": ["spill", "hazard", "blood", "acid", "warning", "fire",
               "smoke", "biohazard", "slime"],
}


def classify_assets(assets) -> dict:
    """Return {category: [{"path","name","w","h"}, ...]}."""
    cats = {c: [] for c in CATEGORIES}
    for a in assets:
        cat = _category(a.name)
        if cat and (a.width or a.height):
            cats[cat].append({"path": a.path, "name": a.name,
                              "w": a.width, "h": a.height})
    return cats


def summarize(cats: dict) -> str:
    return ", ".join(f"{c}:{len(v)}" for c, v in cats.items() if v)


def _category(name: str) -> Optional[str]:
    n = name.lower()
    for cat in CATEGORIES:
        for kw in KEYWORDS[cat]:
            if kw in n:
                return cat
    return None


# --------------------------------------------------------------------------
# Layout
# --------------------------------------------------------------------------
def _place_rooms(rng: random.Random, W, H, opts: dict):
    n = max(1, opts.get("rooms", 6))
    layout = opts.get("layout", "random")
    rooms = []
    attempts = 0
    while len(rooms) < n and attempts < 400:
        attempts += 1
        w = rng.randint(3, 7)
        h = rng.randint(3, 6)
        if layout == "corridors":
            if rooms:
                prev = rooms[-1]
                x = prev[0] + prev[2] + rng.randint(3, 7)
                if x + w >= W - 1:
                    x = rng.randint(1, max(1, W - w - 1))
                y = rng.randint(1, max(1, H - h - 1))
            else:
                x = rng.randint(1, max(1, W - w - 1))
                y = rng.randint(1, max(1, H - h - 1))
        elif layout == "grid":
            cols = max(1, int(math.sqrt(n)))
            i = len(rooms)
            gw = (W - 2) // cols
            gh = (H - 2) // max(1, (n + cols - 1) // cols)
            if gw < 3 or gh < 3:
                x = rng.randint(1, max(1, W - w - 1))
                y = rng.randint(1, max(1, H - h - 1))
            else:
                cx = (i % cols) * gw + 1
                cy = (i // cols) * gh + 1
                x = min(cx, W - w - 1)
                y = min(cy, H - h - 1)
        else:  # random / organic
            x = rng.randint(1, max(1, W - w - 1))
            y = rng.randint(1, max(1, H - h - 1))
        if all(_gap(r, (x, y, w, h)) for r in rooms):
            rooms.append((x, y, w, h))
    return rooms


def _gap(a, b):
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    return not (ax - 1 < bx + bw and ax + aw + 1 > bx and
                ay - 1 < by + bh and ay + ah + 1 > by)


def _carve(rng, grid, rooms):
    # fill rooms
    for (x, y, w, h) in rooms:
        for yy in range(y, y + h):
            for xx in range(x, x + w):
                grid[yy][xx] = 1
    # connect consecutive room centers with L corridors
    for i in range(1, len(rooms)):
        a, b = rooms[i - 1], rooms[i]
        ax, ay = a[0] + a[2] // 2, a[1] + a[3] // 2
        bx, by = b[0] + b[2] // 2, b[1] + b[3] // 2
        x = ax
        step = 1 if bx > ax else -1
        while x != bx:
            grid[ay][x] = 1
            x += step
        y = ay
        step = 1 if by > ay else -1
        while y != by:
            grid[y][bx] = 1
            y += step
        grid[by][bx] = 1


def _walls(grid, W, H):
    for y in range(H):
        for x in range(W):
            if grid[y][x] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < W and 0 <= ny < H and grid[ny][nx] == 1:
                        grid[y][x] = 2
                        break


def _doors(grid, W, H):
    for y in range(H):
        for x in range(W):
            if grid[y][x] == 2:
                floors = 0
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < W and 0 <= ny < H and grid[ny][nx] == 1:
                        floors += 1
                if floors >= 2:
                    grid[y][x] = 3


def _connected(grid, W, H) -> bool:
    start = None
    for y in range(H):
        for x in range(W):
            if grid[y][x] in (1, 3):
                start = (x, y)
                break
        if start:
            break
    if not start:
        return True
    seen = set([start])
    stack = [start]
    while stack:
        x, y = stack.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < W and 0 <= ny < H and grid[ny][nx] in (1, 3) and (nx, ny) not in seen:
                seen.add((nx, ny))
                stack.append((nx, ny))
    total = sum(1 for y in range(H) for x in range(W) if grid[y][x] in (1, 3))
    return len(seen) == total


# --------------------------------------------------------------------------
# Piece helpers
# --------------------------------------------------------------------------
def _mk(a, px, py, w, h, scale, rot, layer_name):
    return {"asset_path": a["path"], "name": a["name"], "x": px, "y": py,
            "w": a["w"], "h": a["h"], "scale": scale, "rotation": rot,
            "layer_name": layer_name, "snap": True, "opacity": 1.0}


def generate(opts: dict) -> dict:
    rng = random.Random(opts.get("seed", 1))
    cs = opts["cell_size"]
    x0, y0, x1, y1 = opts["region"]
    W = x1 - x0 + 1
    H = y1 - y0 + 1
    cats = opts["categories"]
    floor_pool = cats["floor"] + cats["corridor"]
    wall_pool = cats["wall"]
    door_pool = cats["door"] or floor_pool
    wfix = cats["wall_fixture"]
    ffix = cats["floor_fixture"]
    hz = cats["hazard"]
    clutter = max(0, min(1.0, opts.get("clutter", 0.3)))

    grid = [[0] * W for _ in range(H)]
    rooms = _place_rooms(rng, W, H, opts)
    _carve(rng, grid, rooms)
    _walls(grid, W, H)
    _doors(grid, W, H)
    connected = _connected(grid, W, H)

    pieces = []
    for y in range(H):
        for x in range(W):
            t = grid[y][x]
            if t == 1:
                pool = floor_pool
            elif t == 2:
                pool = wall_pool
            elif t == 3:
                pool = door_pool
            else:
                continue
            if not pool:
                continue
            a = rng.choice(pool)
            scale = cs / max(a["w"], a["h"], 1)
            w = a["w"] * scale
            h = a["h"] * scale
            px = (x0 + x) * cs + (cs - w) / 2
            py = (y0 + y) * cs + (cs - h) / 2
            rot = rng.choice([0, 90, 180, 270]) if t != 2 else 0
            pieces.append(_mk(a, px, py, w, h, scale, rot, "Base"))

    # floor fixtures: inside room interiors, density from clutter
    prob = clutter * 0.35
    for (rx, ry, rw, rh) in rooms:
        for yy in range(ry + 1, ry + rh - 1):
            for xx in range(rx + 1, rx + rw - 1):
                if grid[yy][xx] != 1:
                    continue
                if ffix and rng.random() < prob:
                    a = rng.choice(ffix)
                    px = (x0 + xx) * cs + (cs - a["w"]) / 2
                    py = (y0 + yy) * cs + (cs - a["h"]) / 2
                    pieces.append(_mk(a, px, py, a["w"], a["h"], 1.0, 0, "Props"))

    # wall fixtures: on wall cells adjacent to floor
    for y in range(H):
        for x in range(W):
            if grid[y][x] != 2:
                continue
            adj_floor = False
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nx, ny = x + dx, y + dy
                if 0 <= nx < W and 0 <= ny < H and grid[ny][nx] == 1:
                    adj_floor = True
                    break
            if adj_floor and wfix and rng.random() < 0.14:
                a = rng.choice(wfix)
                px = (x0 + x) * cs + (cs - a["w"]) / 2
                py = (y0 + y) * cs + (cs - a["h"]) / 2
                pieces.append(_mk(a, px, py, a["w"], a["h"], 1.0, 0, "Props"))

    # occasional hazard on floors
    if hz:
        for (rx, ry, rw, rh) in rooms:
            if rng.random() < 0.5:
                yy = rng.randint(ry, ry + rh - 1)
                xx = rng.randint(rx, rx + rw - 1)
                if grid[yy][xx] == 1:
                    a = rng.choice(hz)
                    px = (x0 + xx) * cs + (cs - a["w"]) / 2
                    py = (y0 + yy) * cs + (cs - a["h"]) / 2
                    pieces.append(_mk(a, px, py, a["w"], a["h"], 1.0, 0, "Overlay"))

    warnings = []
    if not floor_pool:
        warnings.append("No floor/room tiles found — map may be empty.")
    if not wall_pool:
        warnings.append("No wall tiles found.")
    if not connected:
        warnings.append("Some areas are unreachable (connectivity check failed).")
    return {"pieces": pieces, "seed": opts.get("seed", 1),
            "counts": {"rooms": len(rooms), "pieces": len(pieces)},
            "warnings": warnings, "connected": connected}
