"""Construct the full MainWindow headlessly (offscreen) to catch init errors."""
from __future__ import annotations

import os
import sys

from PyQt6.QtWidgets import QApplication

app = QApplication.instance() or QApplication(sys.argv)

from ui.main_window import MainWindow
from core import exporter

win = MainWindow()
win.show()

root = os.path.join(os.path.dirname(__file__), "sample_assets")
win.project.asset_root = root
win.library.set_project(win.project)
lib = win.library.library
paths = [a.path for a in lib.assets]
assert paths, "no sample assets"

# place pieces
win.canvas.add_asset(paths[0], 50, 50)
win.canvas.add_asset(paths[1], 120, 60)
if win.canvas.selected:
    win.canvas.selected.rotation = 45
    win.canvas.selected.opacity = 0.7

# collections
win.project.collections.setdefault("Favorites", []).append(paths[2])
win.library._rebuild_collections()

# reference overlay
win.props._apply_ref()

# levels
win.level_bar._add()
win.level_bar._add()
assert len(win.project.levels) == 3

# export current level
img = exporter.render_level(win.project, win.project.levels[0], True, 1.0)
out = os.path.join(os.path.dirname(__file__), "gui_test_out.png")
img.save(out, "PNG")
assert os.path.getsize(out) > 1000

# exercise property setters
p = win.project.levels[0].pieces[0]
win.props.load_piece(p)
win.props._set("x", 35)
win.props._rotate(90)

print("GUI HEADLESS OK — pieces:", len(win.project.levels[0].pieces),
      "levels:", len(win.project.levels), "export:", out)
