"""Generator dialog: settings, tile-pool preview, seed / regenerate."""
from __future__ import annotations

import os
from typing import Optional

from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QPixmap, QIcon
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QComboBox, QSlider, QSpinBox,
    QPushButton, QLabel, QHBoxLayout, QGroupBox, QScrollArea, QWidget,
    QMessageBox,
)

from core import generator as gen


def ensure_sizes(assets, library):
    for a in assets:
        if not a.width or not a.height:
            pm = QPixmap(library.abs_path(a.path))
            if not pm.isNull():
                a.width, a.height = pm.width(), pm.height()


class GeneratorDialog(QDialog):
    def __init__(self, project, library, canvas, generate_cb, parent=None):
        super().__init__(parent)
        self.project = project
        self.library = library
        self.canvas = canvas
        self.generate_cb = generate_cb
        self.setWindowTitle("MU-TH-UR 6000 — Map Generator")
        self.setMinimumSize(560, 600)
        self.cats = {}
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        # options
        opt = QGroupBox("Generation")
        f = QFormLayout(opt)
        self.cmb_setting = QComboBox()
        self.cmb_setting.addItems(["Random", "Starship", "Colony base", "Research lab"])
        f.addRow("Setting", self.cmb_setting)
        self.cmb_layout = QComboBox()
        self.cmb_layout.addItems(["Random", "Corridors", "Grid", "Organic"])
        f.addRow("Layout", self.cmb_layout)
        self.sl_clutter = QSlider(Qt.Orientation.Horizontal)
        self.sl_clutter.setRange(0, 100); self.sl_clutter.setValue(35)
        f.addRow("Floor clutter", self.sl_clutter)
        self.spin_seed = QSpinBox(); self.spin_seed.setRange(0, 999999); self.spin_seed.setValue(1)
        f.addRow("Seed", self.spin_seed)
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["New level", "Fill selected area"])
        if not self.canvas.selected_pieces():
            self.cmb_mode.setCurrentIndex(0)
            self.cmb_mode.setEnabled(False)
        f.addRow("Output", self.cmb_mode)
        root.addWidget(opt)

        # preview of classified tiles
        prev = QGroupBox("Auto-classified tiles (view & verify)")
        pv = QVBoxLayout(prev)
        self.prev_area = QScrollArea()
        self.prev_inner = QWidget()
        self.prev_layout = QVBoxLayout(self.prev_inner)
        self.prev_area.setWidget(self.prev_inner)
        self.prev_area.setWidgetResizable(True)
        pv.addWidget(self.prev_area)
        root.addWidget(prev, 1)

        btns = QHBoxLayout()
        b_regen = QPushButton("↻ Regenerate"); b_regen.clicked.connect(self._regen)
        b_gen = QPushButton("Generate"); b_gen.clicked.connect(self._generate)
        btns.addStretch(1); btns.addWidget(b_regen); btns.addWidget(b_gen)
        root.addLayout(btns)

        self._refresh_preview()

    def _taxonomy(self):
        ensure_sizes(self.library.assets, self.library)
        return gen.classify_assets(self.library.assets)

    def _refresh_preview(self):
        self.cats = self._taxonomy()
        while self.prev_layout.count():
            self.prev_layout.takeAt(0).widget().deleteLater()
        for cat in gen.CATEGORIES:
            items = self.cats.get(cat, [])
            row = QHBoxLayout()
            row.addWidget(QLabel(f"<b>{cat}</b> ({len(items)})"))
            row.addStretch(1)
            shown = 0
            for a in items[:8]:
                pm = QPixmap(self.library.abs_path(a.path))
                if not pm.isNull():
                    ic = QLabel()
                    ic.setPixmap(pm.scaled(40, 40, Qt.AspectRatioMode.KeepAspectRatio,
                                          Qt.TransformationMode.SmoothTransformation))
                    ic.setToolTip(a.name)
                    row.addWidget(ic)
                    shown += 1
            if shown == 0:
                row.addWidget(QLabel("(none)"))
            self.prev_layout.addLayout(row)
        self.prev_layout.addStretch(1)

    def _opts(self):
        return {
            "setting": self.cmb_setting.currentText(),
            "layout": self.cmb_layout.currentText(),
            "clutter": self.sl_clutter.value() / 100.0,
            "seed": self.spin_seed.value(),
            "mode": "area" if self.cmb_mode.currentIndex() == 1 else "new",
            "categories": self.cats,
        }

    def _regen(self):
        self.spin_seed.setValue(self.spin_seed.value() + 1)

    def _generate(self):
        if not self.cats.get("floor") and not (self.cats.get("floor") or self.cats.get("corridor")):
            QMessageBox.warning(self, "No tiles", "No floor/room tiles were detected. "
                                             "Import some floor/room PNGs first.")
            return
        opts = self._opts()
        self.generate_cb(opts)
        self.accept()
