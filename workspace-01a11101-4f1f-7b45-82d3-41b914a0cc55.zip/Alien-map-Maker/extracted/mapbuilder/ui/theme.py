"""MUTHER-style sci-fi theme: dark CRT look, glowing accent, scanlines, boot text."""
from __future__ import annotations

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QColor, QPainter, QFont
from PyQt6.QtWidgets import QWidget, QLabel, QApplication


def hex_with_alpha(hex_color: str, alpha: float) -> str:
    c = QColor(hex_color)
    return f"rgba({c.red()},{c.green()},{c.blue()},{alpha:.2f})"


def build_stylesheet(accent: str, text_scale: float) -> str:
    base = int(11 * text_scale)
    bg = "#080b10"
    panel = "#0d1219"
    panel2 = "#111824"
    border = hex_with_alpha(accent, 0.45)
    muted = "#6f8a86"
    sel = hex_with_alpha(accent, 0.25)
    return f"""
    QWidget {{
        background-color: {bg};
        color: {accent};
        font-family: 'Consolas', 'Courier New', monospace;
        font-size: {base}px;
    }}
    QMainWindow, QDialog {{ background-color: {bg}; }}
    QMenuBar {{ background-color: {panel}; border-bottom: 1px solid {border}; }}
    QMenuBar::item:selected {{ background: {sel}; }}
    QMenu {{ background: {panel}; border: 1px solid {border}; }}
    QMenu::item:selected {{ background: {sel}; }}
    QGroupBox {{
        border: 1px solid {border}; margin-top: 14px; padding-top: 6px; color: {accent};
    }}
    QGroupBox::title {{
        subcontrol-origin: margin; left: 8px; padding: 0 4px; color: {accent};
    }}
    QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {{
        background: {panel2}; border: 1px solid {border}; padding: 3px;
        color: {accent}; selection-background-color: {sel};
    }}
    QPushButton {{
        background: {panel2}; border: 1px solid {border}; padding: 5px 8px; color: {accent};
    }}
    QPushButton:hover {{ background: {sel}; }}
    QPushButton:pressed {{ background: {border}; }}
    QListWidget, QTreeWidget, QTabBar {{ background: {panel}; border: 1px solid {border}; color: {accent}; }}
    QListWidget::item:selected, QTreeWidget::item:selected {{ background: {sel}; color: {accent}; }}
    QTabBar::tab {{ background: {panel}; padding: 5px 10px; }}
    QTabBar::tab:selected {{ background: {sel}; border-bottom: 2px solid {accent}; }}
    QSlider::groove:horizontal {{ background: {panel2}; height: 4px; }}
    QSlider::handle:horizontal {{ background: {accent}; width: 12px; }}
    QScrollBar {{ background: {panel}; }}
    QScrollBar::handle {{ background: {border}; }}
    QLabel {{ color: {accent}; }}
    QStatusBar {{ background: {panel}; color: {muted}; }}
    QHeaderView::section {{ background: {panel2}; color: {accent}; border: 1px solid {border}; }}
    """


def apply_stylesheet(app: QApplication, accent: str, text_scale: float):
    app.setStyleSheet(build_stylesheet(accent, text_scale))


class ScanlineOverlay(QWidget):
    def __init__(self, parent=None, accent: str = "#9bff9b"):
        super().__init__(parent)
        self.accent = accent
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)

    def set_accent(self, accent: str):
        self.accent = accent
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setPen(Qt.PenStyle.NoPen)
        c = QColor(self.accent)
        for y in range(0, self.height(), 3):
            p.setBrush(QColor(c.red(), c.green(), c.blue(), 22))
            p.drawRect(0, y, self.width(), 1)
        p.end()


class BootOverlay(QWidget):
    def __init__(self, parent=None, accent: str = "#9bff9b"):
        super().__init__(parent)
        self.accent = accent
        self.label = QLabel("MU-TH-UR 6000\n\n> INITIALIZING SHIP SYSTEMS…", self)
        self.label.setStyleSheet(f"color: {accent}; background: transparent;")
        self.label.setFont(QFont("Consolas", 20))
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet("background: rgba(4,6,9,235);")
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.fade)

    def show_boot(self, ms: int = 1600):
        if self.parent():
            self.resize(self.parent().size())
        self.show()
        self.timer.start(ms)

    def fade(self):
        self.timer.stop()
        self.hide()
