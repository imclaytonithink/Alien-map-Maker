# MU-TH-UR 6000 — Sci-Fi Battlemap Builder

A desktop app for assembling PNG map pieces into sci-fi battlemaps: snap them
to a grid, rotate/flip, drop free overlays, tint/recolor, add text labels,
manage floors/levels, overlay a reference floor, and export to PNG or PDF.

Built with **Python + PyQt6**. Packaged to a standalone `.exe` via PyInstaller.

---

## Running from source (any OS with Python)
```bash
pip install -r requirements.txt
python main.py
```
On first launch you'll see the **launch screen**: pick *New map*, open a
*Recent* map (thumbnail preview), or start from a *Template*. The launch
screen also has the **theme picker** (Green / Amber / Red + scanline/boot toggles).

## Building the .exe (Windows)
1. Install Python 3.10+ from python.org (tick "Add Python to PATH").
2. Run `build.bat` (double-click). Your `.exe` appears at `dist/BattlemapBuilder.exe`.

> PyInstaller can't cross-compile from Linux/macOS, so build the `.exe` on Windows.

---

## How to use

### 1. Bring your pictures into the tool (stays forever)
- **Import Folder** / **Import File** (top of the library panel) copies your
  PNGs into the app's internal store. They're auto-grouped by their source
  subfolder, auto-tagged by type/size, and you can reorder groups with ▲▼.
- **Custom single PNGs** dragged straight onto the canvas are *embedded* inside
  the saved `.bmap` file, so that map is portable on its own.

### 2. Browse & preview
- Search by name or size (e.g. `40x120`).
- Hover an asset ~0.6s for a pop-out preview; **right-click → View larger…**
  for a full preview with an *Add to canvas* button.
- Drag an asset onto the canvas, or double-click to drop at center.
- Thumbnail size slider on the left.

### 3. Build the map
- **Left-drag** a piece to move (snaps if enabled). **Yellow handle** = rotate
  (hold **Shift** for 15°). **Right/Middle-drag** pans; **wheel** zooms.
- Multi-select: **Shift-click** or drag a marquee. Then align / distribute /
  **Glue** (group) / tint / delete / duplicate / copy-paste together.
- The **quick toolbar** (top-right of canvas) rotates/flips, raises/lowers,
  locks, copies, duplicates, deletes the selection.
- **Tint** a piece (or whole selection) with a color picker + strength slider.
- **Text** tool adds labels with font/size/bold/color (color picker included).
- **Grid**: square grid with opacity slider, solid/dashed/dotted style, major
  lines every N cells, adjustable cell size & "square = 5ft/10ft". The square
  under your cursor is highlighted while placing. **Smart guides** snap piece
  edges/centers to neighbors.

### 4. Floors / Levels
- Tab bar above the canvas: add / remove / rename / reorder floors.
- **Reference floor overlay**: ghost the floor above/below (adjustable opacity)
  so you can align things between levels.
- **Layers** (right panel): per-level layers with show/hide, lock, opacity,
  reorder, and an *active layer* that new pieces go to.

### 5. Export
- **Export PNG…**: current level or all levels, size presets (Foundry, Roll20,
  **Tabletop Simulator**, Print 2×/4×), transparent background, and a separate
  **grid on/off + color + opacity** for the exported image.
- **Export PDF…**: one page per level.

### 6. Save / Open
- Projects are `.bmap` JSON (placements, tints, text, embedded custom images,
  layers, theme). A thumbnail is saved next to the file for the launch screen.
- **Undo/Redo** (Ctrl+Z / Ctrl+Y) with named history; arrow keys nudge
  (hold **Shift** = one grid cell).

---

## Project layout
```
core/   project (data model) · history (undo/redo) · asset_manager (internal
        store) · exporter (PNG/PDF) · render (shared piece drawing)
ui/     main_window · canvas · library · properties · layers_panel ·
        launch_screen · theme (MUTHER look) · export_dialog
sample_assets/   demo pieces
```
